
int main(void)
{
while	(1)
	{
	}
}
